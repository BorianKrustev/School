﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _4.Telephony
{
	public interface IBrows
	{
		void Brows(string url);
	}
}
