﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _8.MilitaryElite.Enums
{
	public enum State
	{
		inProgress = 1,
		Finished = 2
	}
}
