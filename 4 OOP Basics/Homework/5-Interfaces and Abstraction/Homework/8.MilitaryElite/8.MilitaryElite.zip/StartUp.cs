﻿using _8.MilitaryElite.Core;
using System;

namespace _8.MilitaryElite
{
	public class StartUp
	{
		public static void Main(string[] args)
		{
			Engine engine = new Engine();
			engine.Run();
		}
	}
}
