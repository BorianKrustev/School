﻿namespace PetClinic.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=PetClinic;Trusted_Connection=True";
    }
}
